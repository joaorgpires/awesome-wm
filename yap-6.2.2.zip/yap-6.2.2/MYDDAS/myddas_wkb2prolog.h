#ifndef   	MYDDAS_WKB2PROLOG_H_
# define   	MYDDAS_WKB2PROLOG_H_

Term wkb2prolog(char *wkb) ;

#endif 	    /* !MYDDAS_WKB2PROLOG_H_ */
