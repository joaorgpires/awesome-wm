
  /* This file, tatoms.h, was generated automatically by "yap -L misc/buildatoms"
     please do not update, update misc/ATOMS instead */

  Atom Atom3Dots_;
#define Atom3Dots Yap_heap_regs->Atom3Dots_
  Atom AtomAbol_;
#define AtomAbol Yap_heap_regs->AtomAbol_
  Atom AtomAccess_;
#define AtomAccess Yap_heap_regs->AtomAccess_
  Atom AtomAfInet_;
#define AtomAfInet Yap_heap_regs->AtomAfInet_
  Atom AtomAfLocal_;
#define AtomAfLocal Yap_heap_regs->AtomAfLocal_
  Atom AtomAfUnix_;
#define AtomAfUnix Yap_heap_regs->AtomAfUnix_
  Atom AtomAlarm_;
#define AtomAlarm Yap_heap_regs->AtomAlarm_
  Atom AtomAlias_;
#define AtomAlias Yap_heap_regs->AtomAlias_
  Atom AtomAltNot_;
#define AtomAltNot Yap_heap_regs->AtomAltNot_
  Atom AtomAppend_;
#define AtomAppend Yap_heap_regs->AtomAppend_
  Atom AtomArg_;
#define AtomArg Yap_heap_regs->AtomArg_
  Atom AtomArray_;
#define AtomArray Yap_heap_regs->AtomArray_
  Atom AtomArrayAccess_;
#define AtomArrayAccess Yap_heap_regs->AtomArrayAccess_
  Atom AtomArrayOverflow_;
#define AtomArrayOverflow Yap_heap_regs->AtomArrayOverflow_
  Atom AtomArrayType_;
#define AtomArrayType Yap_heap_regs->AtomArrayType_
  Atom AtomArrow_;
#define AtomArrow Yap_heap_regs->AtomArrow_
  Atom AtomAssert_;
#define AtomAssert Yap_heap_regs->AtomAssert_
  Atom AtomAt_;
#define AtomAt Yap_heap_regs->AtomAt_
  Atom AtomAtom_;
#define AtomAtom Yap_heap_regs->AtomAtom_
  Atom AtomAtomic_;
#define AtomAtomic Yap_heap_regs->AtomAtomic_
  Atom AtomAtt_;
#define AtomAtt Yap_heap_regs->AtomAtt_
  Atom AtomAtt1_;
#define AtomAtt1 Yap_heap_regs->AtomAtt1_
  Atom AtomAttDo_;
#define AtomAttDo Yap_heap_regs->AtomAttDo_
  Atom AtomAttributes_;
#define AtomAttributes Yap_heap_regs->AtomAttributes_
  Atom AtomB_;
#define AtomB Yap_heap_regs->AtomB_
  Atom AtomBatched_;
#define AtomBatched Yap_heap_regs->AtomBatched_
  Atom AtomBetween_;
#define AtomBetween Yap_heap_regs->AtomBetween_
  Atom AtomHugeInt_;
#define AtomHugeInt Yap_heap_regs->AtomHugeInt_
  Atom AtomBinaryStream_;
#define AtomBinaryStream Yap_heap_regs->AtomBinaryStream_
  Atom AtomBraces_;
#define AtomBraces Yap_heap_regs->AtomBraces_
  Atom AtomBreak_;
#define AtomBreak Yap_heap_regs->AtomBreak_
  Atom AtomByte_;
#define AtomByte Yap_heap_regs->AtomByte_
  Atom AtomCArith_;
#define AtomCArith Yap_heap_regs->AtomCArith_
  Atom AtomCall_;
#define AtomCall Yap_heap_regs->AtomCall_
  Atom AtomCallAndRetryCounter_;
#define AtomCallAndRetryCounter Yap_heap_regs->AtomCallAndRetryCounter_
  Atom AtomCallCounter_;
#define AtomCallCounter Yap_heap_regs->AtomCallCounter_
  Atom AtomCallable_;
#define AtomCallable Yap_heap_regs->AtomCallable_
  Atom AtomCatch_;
#define AtomCatch Yap_heap_regs->AtomCatch_
  Atom AtomChangeModule_;
#define AtomChangeModule Yap_heap_regs->AtomChangeModule_
  Atom AtomChar_;
#define AtomChar Yap_heap_regs->AtomChar_
  Atom AtomCharsio_;
#define AtomCharsio Yap_heap_regs->AtomCharsio_
  Atom AtomCharacter_;
#define AtomCharacter Yap_heap_regs->AtomCharacter_
  Atom AtomCharacterCode_;
#define AtomCharacterCode Yap_heap_regs->AtomCharacterCode_
  Atom AtomCleanCall_;
#define AtomCleanCall Yap_heap_regs->AtomCleanCall_
  Atom AtomColomn_;
#define AtomColomn Yap_heap_regs->AtomColomn_
  Atom AtomCodeSpace_;
#define AtomCodeSpace Yap_heap_regs->AtomCodeSpace_
  Atom AtomCodes_;
#define AtomCodes Yap_heap_regs->AtomCodes_
  Atom AtomComma_;
#define AtomComma Yap_heap_regs->AtomComma_
  Atom AtomCompound_;
#define AtomCompound Yap_heap_regs->AtomCompound_
  Atom AtomConsistencyError_;
#define AtomConsistencyError Yap_heap_regs->AtomConsistencyError_
  Atom AtomConsultOnBoot_;
#define AtomConsultOnBoot Yap_heap_regs->AtomConsultOnBoot_
  Atom AtomContext_;
#define AtomContext Yap_heap_regs->AtomContext_
  Atom AtomCputime_;
#define AtomCputime Yap_heap_regs->AtomCputime_
  Atom AtomCreate_;
#define AtomCreate Yap_heap_regs->AtomCreate_
  Atom AtomCreep_;
#define AtomCreep Yap_heap_regs->AtomCreep_
  Atom AtomCryptAtoms_;
#define AtomCryptAtoms Yap_heap_regs->AtomCryptAtoms_
  Atom AtomCsult_;
#define AtomCsult Yap_heap_regs->AtomCsult_
  Atom AtomCurrentModule_;
#define AtomCurrentModule Yap_heap_regs->AtomCurrentModule_
  Atom AtomCut_;
#define AtomCut Yap_heap_regs->AtomCut_
  Atom AtomCutBy_;
#define AtomCutBy Yap_heap_regs->AtomCutBy_
  Atom AtomDAbort_;
#define AtomDAbort Yap_heap_regs->AtomDAbort_
  Atom AtomDBREF_;
#define AtomDBREF Yap_heap_regs->AtomDBREF_
  Atom AtomDBReference_;
#define AtomDBReference Yap_heap_regs->AtomDBReference_
  Atom AtomDBTerm_;
#define AtomDBTerm Yap_heap_regs->AtomDBTerm_
  Atom AtomDBref_;
#define AtomDBref Yap_heap_regs->AtomDBref_
  Atom AtomDInteger_;
#define AtomDInteger Yap_heap_regs->AtomDInteger_
  Atom AtomDOUBLE_;
#define AtomDOUBLE Yap_heap_regs->AtomDOUBLE_
  Atom AtomDec10_;
#define AtomDec10 Yap_heap_regs->AtomDec10_
  Atom AtomDefault_;
#define AtomDefault Yap_heap_regs->AtomDefault_
  Atom AtomDevNull_;
#define AtomDevNull Yap_heap_regs->AtomDevNull_
  Atom AtomDiff_;
#define AtomDiff Yap_heap_regs->AtomDiff_
  Atom AtomDoLogUpdClause_;
#define AtomDoLogUpdClause Yap_heap_regs->AtomDoLogUpdClause_
  Atom AtomDoLogUpdClause0_;
#define AtomDoLogUpdClause0 Yap_heap_regs->AtomDoLogUpdClause0_
  Atom AtomDoLogUpdClauseErase_;
#define AtomDoLogUpdClauseErase Yap_heap_regs->AtomDoLogUpdClauseErase_
  Atom AtomDoStaticClause_;
#define AtomDoStaticClause Yap_heap_regs->AtomDoStaticClause_
  Atom AtomDollarU_;
#define AtomDollarU Yap_heap_regs->AtomDollarU_
  Atom AtomDollarUndef_;
#define AtomDollarUndef Yap_heap_regs->AtomDollarUndef_
  Atom AtomDomainError_;
#define AtomDomainError Yap_heap_regs->AtomDomainError_
  Atom AtomE_;
#define AtomE Yap_heap_regs->AtomE_
  Atom AtomEOFBeforeEOT_;
#define AtomEOFBeforeEOT Yap_heap_regs->AtomEOFBeforeEOT_
  Atom AtomEQ_;
#define AtomEQ Yap_heap_regs->AtomEQ_
  Atom AtomEmptyAtom_;
#define AtomEmptyAtom Yap_heap_regs->AtomEmptyAtom_
  Atom AtomEncoding_;
#define AtomEncoding Yap_heap_regs->AtomEncoding_
  Atom AtomEndOfStream_;
#define AtomEndOfStream Yap_heap_regs->AtomEndOfStream_
  Atom AtomEof_;
#define AtomEof Yap_heap_regs->AtomEof_
  Atom AtomEq_;
#define AtomEq Yap_heap_regs->AtomEq_
  Atom AtomError_;
#define AtomError Yap_heap_regs->AtomError_
  Atom AtomEvaluable_;
#define AtomEvaluable Yap_heap_regs->AtomEvaluable_
  Atom AtomEvaluationError_;
#define AtomEvaluationError Yap_heap_regs->AtomEvaluationError_
  Atom AtomExecute_;
#define AtomExecute Yap_heap_regs->AtomExecute_
  Atom AtomExecAnswers_;
#define AtomExecAnswers Yap_heap_regs->AtomExecAnswers_
  Atom AtomExecuteInMod_;
#define AtomExecuteInMod Yap_heap_regs->AtomExecuteInMod_
  Atom AtomExecuteWithin_;
#define AtomExecuteWithin Yap_heap_regs->AtomExecuteWithin_
  Atom AtomExecuteWoMod_;
#define AtomExecuteWoMod Yap_heap_regs->AtomExecuteWoMod_
  Atom AtomExist_;
#define AtomExist Yap_heap_regs->AtomExist_
  Atom AtomExistenceError_;
#define AtomExistenceError Yap_heap_regs->AtomExistenceError_
  Atom AtomExpectedNumber_;
#define AtomExpectedNumber Yap_heap_regs->AtomExpectedNumber_
  Atom AtomExtendFileSearchPath_;
#define AtomExtendFileSearchPath Yap_heap_regs->AtomExtendFileSearchPath_
  Atom AtomFB_;
#define AtomFB Yap_heap_regs->AtomFB_
  Atom AtomFail_;
#define AtomFail Yap_heap_regs->AtomFail_
  Atom AtomFalse_;
#define AtomFalse Yap_heap_regs->AtomFalse_
  Atom AtomFast_;
#define AtomFast Yap_heap_regs->AtomFast_
  Atom AtomFileerrors_;
#define AtomFileerrors Yap_heap_regs->AtomFileerrors_
  Atom AtomFloat_;
#define AtomFloat Yap_heap_regs->AtomFloat_
  Atom AtomFloatFormat_;
#define AtomFloatFormat Yap_heap_regs->AtomFloatFormat_
  Atom AtomFloatOverflow_;
#define AtomFloatOverflow Yap_heap_regs->AtomFloatOverflow_
  Atom AtomFloatUnderflow_;
#define AtomFloatUnderflow Yap_heap_regs->AtomFloatUnderflow_
  Atom AtomFormat_;
#define AtomFormat Yap_heap_regs->AtomFormat_
  Atom AtomFormatAt_;
#define AtomFormatAt Yap_heap_regs->AtomFormatAt_
  Atom AtomFunctor_;
#define AtomFunctor Yap_heap_regs->AtomFunctor_
  Atom AtomGT_;
#define AtomGT Yap_heap_regs->AtomGT_
  Atom AtomGVar_;
#define AtomGVar Yap_heap_regs->AtomGVar_
  Atom AtomGc_;
#define AtomGc Yap_heap_regs->AtomGc_
  Atom AtomGcMargin_;
#define AtomGcMargin Yap_heap_regs->AtomGcMargin_
  Atom AtomGcTrace_;
#define AtomGcTrace Yap_heap_regs->AtomGcTrace_
  Atom AtomGcVerbose_;
#define AtomGcVerbose Yap_heap_regs->AtomGcVerbose_
  Atom AtomGcVeryVerbose_;
#define AtomGcVeryVerbose Yap_heap_regs->AtomGcVeryVerbose_
  Atom AtomGeneratePredInfo_;
#define AtomGeneratePredInfo Yap_heap_regs->AtomGeneratePredInfo_
  Atom AtomGetwork_;
#define AtomGetwork Yap_heap_regs->AtomGetwork_
  Atom AtomGetworkSeq_;
#define AtomGetworkSeq Yap_heap_regs->AtomGetworkSeq_
  Atom AtomGlobalSp_;
#define AtomGlobalSp Yap_heap_regs->AtomGlobalSp_
  Atom AtomGlobalTrie_;
#define AtomGlobalTrie Yap_heap_regs->AtomGlobalTrie_
  Atom AtomGoalExpansion_;
#define AtomGoalExpansion Yap_heap_regs->AtomGoalExpansion_
  Atom AtomHERE_;
#define AtomHERE Yap_heap_regs->AtomHERE_
  Atom AtomHandleThrow_;
#define AtomHandleThrow Yap_heap_regs->AtomHandleThrow_
  Atom AtomHeap_;
#define AtomHeap Yap_heap_regs->AtomHeap_
  Atom AtomHeapUsed_;
#define AtomHeapUsed Yap_heap_regs->AtomHeapUsed_
  Atom AtomIDB_;
#define AtomIDB Yap_heap_regs->AtomIDB_
  Atom AtomIOMode_;
#define AtomIOMode Yap_heap_regs->AtomIOMode_
  Atom AtomId_;
#define AtomId Yap_heap_regs->AtomId_
  Atom AtomInf_;
#define AtomInf Yap_heap_regs->AtomInf_
  Atom AtomInitGoal_;
#define AtomInitGoal Yap_heap_regs->AtomInitGoal_
  Atom AtomInStackExpansion_;
#define AtomInStackExpansion Yap_heap_regs->AtomInStackExpansion_
  Atom AtomInput_;
#define AtomInput Yap_heap_regs->AtomInput_
  Atom AtomInstantiationError_;
#define AtomInstantiationError Yap_heap_regs->AtomInstantiationError_
  Atom AtomInt_;
#define AtomInt Yap_heap_regs->AtomInt_
  Atom AtomIntOverflow_;
#define AtomIntOverflow Yap_heap_regs->AtomIntOverflow_
  Atom AtomInteger_;
#define AtomInteger Yap_heap_regs->AtomInteger_
  Atom AtomInternalCompilerError_;
#define AtomInternalCompilerError Yap_heap_regs->AtomInternalCompilerError_
  Atom AtomIs_;
#define AtomIs Yap_heap_regs->AtomIs_
  Atom AtomKey_;
#define AtomKey Yap_heap_regs->AtomKey_
  Atom AtomLDLibraryPath_;
#define AtomLDLibraryPath Yap_heap_regs->AtomLDLibraryPath_
  Atom AtomLONGINT_;
#define AtomLONGINT Yap_heap_regs->AtomLONGINT_
  Atom AtomLT_;
#define AtomLT Yap_heap_regs->AtomLT_
  Atom AtomLastExecuteWithin_;
#define AtomLastExecuteWithin Yap_heap_regs->AtomLastExecuteWithin_
  Atom AtomLeash_;
#define AtomLeash Yap_heap_regs->AtomLeash_
  Atom AtomList_;
#define AtomList Yap_heap_regs->AtomList_
  Atom AtomLive_;
#define AtomLive Yap_heap_regs->AtomLive_
  Atom AtomLoadAnswers_;
#define AtomLoadAnswers Yap_heap_regs->AtomLoadAnswers_
  Atom AtomLocal_;
#define AtomLocal Yap_heap_regs->AtomLocal_
  Atom AtomLocalSp_;
#define AtomLocalSp Yap_heap_regs->AtomLocalSp_
  Atom AtomLocalTrie_;
#define AtomLocalTrie Yap_heap_regs->AtomLocalTrie_
  Atom AtomMaxArity_;
#define AtomMaxArity Yap_heap_regs->AtomMaxArity_
  Atom AtomMaxFiles_;
#define AtomMaxFiles Yap_heap_regs->AtomMaxFiles_
  Atom AtomMegaClause_;
#define AtomMegaClause Yap_heap_regs->AtomMegaClause_
  Atom AtomMetaCall_;
#define AtomMetaCall Yap_heap_regs->AtomMetaCall_
  Atom AtomMfClause_;
#define AtomMfClause Yap_heap_regs->AtomMfClause_
  Atom AtomMinus_;
#define AtomMinus Yap_heap_regs->AtomMinus_
  Atom AtomModify_;
#define AtomModify Yap_heap_regs->AtomModify_
  Atom AtomMultiFile_;
#define AtomMultiFile Yap_heap_regs->AtomMultiFile_
  Atom AtomMutable_;
#define AtomMutable Yap_heap_regs->AtomMutable_
  Atom AtomMutableVariable_;
#define AtomMutableVariable Yap_heap_regs->AtomMutableVariable_
  Atom AtomMyddasDB_;
#define AtomMyddasDB Yap_heap_regs->AtomMyddasDB_
  Atom AtomMyddasGoal_;
#define AtomMyddasGoal Yap_heap_regs->AtomMyddasGoal_
  Atom AtomMyddasHost_;
#define AtomMyddasHost Yap_heap_regs->AtomMyddasHost_
  Atom AtomMyddasPass_;
#define AtomMyddasPass Yap_heap_regs->AtomMyddasPass_
  Atom AtomMyddasUser_;
#define AtomMyddasUser Yap_heap_regs->AtomMyddasUser_
  Atom AtomMyddasVersionName_;
#define AtomMyddasVersionName Yap_heap_regs->AtomMyddasVersionName_
  Atom AtomNan_;
#define AtomNan Yap_heap_regs->AtomNan_
  Atom AtomNb_;
#define AtomNb Yap_heap_regs->AtomNb_
  Atom AtomNbTerm_;
#define AtomNbTerm Yap_heap_regs->AtomNbTerm_
  Atom AtomNew_;
#define AtomNew Yap_heap_regs->AtomNew_
  Atom AtomNoMemory_;
#define AtomNoMemory Yap_heap_regs->AtomNoMemory_
  Atom AtomNone_;
#define AtomNone Yap_heap_regs->AtomNone_
  Atom AtomNonEmptyList_;
#define AtomNonEmptyList Yap_heap_regs->AtomNonEmptyList_
  Atom AtomNot_;
#define AtomNot Yap_heap_regs->AtomNot_
  Atom AtomNotImplemented_;
#define AtomNotImplemented Yap_heap_regs->AtomNotImplemented_
  Atom AtomNotLessThanZero_;
#define AtomNotLessThanZero Yap_heap_regs->AtomNotLessThanZero_
  Atom AtomNotNewline_;
#define AtomNotNewline Yap_heap_regs->AtomNotNewline_
  Atom AtomNotZero_;
#define AtomNotZero Yap_heap_regs->AtomNotZero_
  Atom AtomNumber_;
#define AtomNumber Yap_heap_regs->AtomNumber_
  Atom AtomOff_;
#define AtomOff Yap_heap_regs->AtomOff_
  Atom AtomOffline_;
#define AtomOffline Yap_heap_regs->AtomOffline_
  Atom AtomOn_;
#define AtomOn Yap_heap_regs->AtomOn_
  Atom AtomOnline_;
#define AtomOnline Yap_heap_regs->AtomOnline_
  Atom AtomOpen_;
#define AtomOpen Yap_heap_regs->AtomOpen_
  Atom AtomOperatingSystemError_;
#define AtomOperatingSystemError Yap_heap_regs->AtomOperatingSystemError_
  Atom AtomOperatingSystemSupport_;
#define AtomOperatingSystemSupport Yap_heap_regs->AtomOperatingSystemSupport_
  Atom AtomOperator_;
#define AtomOperator Yap_heap_regs->AtomOperator_
  Atom AtomOperatorPriority_;
#define AtomOperatorPriority Yap_heap_regs->AtomOperatorPriority_
  Atom AtomOperatorSpecifier_;
#define AtomOperatorSpecifier Yap_heap_regs->AtomOperatorSpecifier_
  Atom AtomOtherwise_;
#define AtomOtherwise Yap_heap_regs->AtomOtherwise_
  Atom AtomOutOfAttvarsError_;
#define AtomOutOfAttvarsError Yap_heap_regs->AtomOutOfAttvarsError_
  Atom AtomOutOfAuxspaceError_;
#define AtomOutOfAuxspaceError Yap_heap_regs->AtomOutOfAuxspaceError_
  Atom AtomOutOfHeapError_;
#define AtomOutOfHeapError Yap_heap_regs->AtomOutOfHeapError_
  Atom AtomOutOfRange_;
#define AtomOutOfRange Yap_heap_regs->AtomOutOfRange_
  Atom AtomOutOfStackError_;
#define AtomOutOfStackError Yap_heap_regs->AtomOutOfStackError_
  Atom AtomOutOfTrailError_;
#define AtomOutOfTrailError Yap_heap_regs->AtomOutOfTrailError_
  Atom AtomOutput_;
#define AtomOutput Yap_heap_regs->AtomOutput_
  Atom AtomPrologCommonsDir_;
#define AtomPrologCommonsDir Yap_heap_regs->AtomPrologCommonsDir_
  Atom AtomPastEndOfStream_;
#define AtomPastEndOfStream Yap_heap_regs->AtomPastEndOfStream_
  Atom AtomPermissionError_;
#define AtomPermissionError Yap_heap_regs->AtomPermissionError_
  Atom AtomPi_;
#define AtomPi Yap_heap_regs->AtomPi_
  Atom AtomPipe_;
#define AtomPipe Yap_heap_regs->AtomPipe_
  Atom AtomPlus_;
#define AtomPlus Yap_heap_regs->AtomPlus_
  Atom AtomPointer_;
#define AtomPointer Yap_heap_regs->AtomPointer_
  Atom AtomPortray_;
#define AtomPortray Yap_heap_regs->AtomPortray_
  Atom AtomPredicateIndicator_;
#define AtomPredicateIndicator Yap_heap_regs->AtomPredicateIndicator_
  Atom AtomPrimitive_;
#define AtomPrimitive Yap_heap_regs->AtomPrimitive_
  Atom AtomPrivateProcedure_;
#define AtomPrivateProcedure Yap_heap_regs->AtomPrivateProcedure_
  Atom AtomProcedure_;
#define AtomProcedure Yap_heap_regs->AtomProcedure_
  Atom AtomProfile_;
#define AtomProfile Yap_heap_regs->AtomProfile_
  Atom AtomProlog_;
#define AtomProlog Yap_heap_regs->AtomProlog_
  Atom AtomPtr_;
#define AtomPtr Yap_heap_regs->AtomPtr_
  Atom AtomQuery_;
#define AtomQuery Yap_heap_regs->AtomQuery_
  Atom AtomQueue_;
#define AtomQueue Yap_heap_regs->AtomQueue_
  Atom AtomQuiet_;
#define AtomQuiet Yap_heap_regs->AtomQuiet_
  Atom AtomRadix_;
#define AtomRadix Yap_heap_regs->AtomRadix_
  Atom AtomRandom_;
#define AtomRandom Yap_heap_regs->AtomRandom_
  Atom AtomRead_;
#define AtomRead Yap_heap_regs->AtomRead_
  Atom AtomReadutil_;
#define AtomReadutil Yap_heap_regs->AtomReadutil_
  Atom AtomRecordedP_;
#define AtomRecordedP Yap_heap_regs->AtomRecordedP_
  Atom AtomRecordedWithKey_;
#define AtomRecordedWithKey Yap_heap_regs->AtomRecordedWithKey_
  Atom AtomRedoFreeze_;
#define AtomRedoFreeze Yap_heap_regs->AtomRedoFreeze_
  Atom AtomRefoundVar_;
#define AtomRefoundVar Yap_heap_regs->AtomRefoundVar_
  Atom AtomRepeat_;
#define AtomRepeat Yap_heap_regs->AtomRepeat_
  Atom AtomRepeatSpace_;
#define AtomRepeatSpace Yap_heap_regs->AtomRepeatSpace_
  Atom AtomReposition_;
#define AtomReposition Yap_heap_regs->AtomReposition_
  Atom AtomRepresentationError_;
#define AtomRepresentationError Yap_heap_regs->AtomRepresentationError_
  Atom AtomRDiv_;
#define AtomRDiv Yap_heap_regs->AtomRDiv_
  Atom AtomResize_;
#define AtomResize Yap_heap_regs->AtomResize_
  Atom AtomResourceError_;
#define AtomResourceError Yap_heap_regs->AtomResourceError_
  Atom AtomRestoreRegs_;
#define AtomRestoreRegs Yap_heap_regs->AtomRestoreRegs_
  Atom AtomRetryCounter_;
#define AtomRetryCounter Yap_heap_regs->AtomRetryCounter_
  Atom AtomRTree_;
#define AtomRTree Yap_heap_regs->AtomRTree_
  Atom AtomSafe_;
#define AtomSafe Yap_heap_regs->AtomSafe_
  Atom AtomSafeCallCleanup_;
#define AtomSafeCallCleanup Yap_heap_regs->AtomSafeCallCleanup_
  Atom AtomSame_;
#define AtomSame Yap_heap_regs->AtomSame_
  Atom AtomSemic_;
#define AtomSemic Yap_heap_regs->AtomSemic_
  Atom AtomShiftCountOverflow_;
#define AtomShiftCountOverflow Yap_heap_regs->AtomShiftCountOverflow_
  Atom AtomSigAlarm_;
#define AtomSigAlarm Yap_heap_regs->AtomSigAlarm_
  Atom AtomSigBreak_;
#define AtomSigBreak Yap_heap_regs->AtomSigBreak_
  Atom AtomSigCreep_;
#define AtomSigCreep Yap_heap_regs->AtomSigCreep_
  Atom AtomSigDebug_;
#define AtomSigDebug Yap_heap_regs->AtomSigDebug_
  Atom AtomSigDelayCreep_;
#define AtomSigDelayCreep Yap_heap_regs->AtomSigDelayCreep_
  Atom AtomSigHup_;
#define AtomSigHup Yap_heap_regs->AtomSigHup_
  Atom AtomSigInt_;
#define AtomSigInt Yap_heap_regs->AtomSigInt_
  Atom AtomSigIti_;
#define AtomSigIti Yap_heap_regs->AtomSigIti_
  Atom AtomSigPending_;
#define AtomSigPending Yap_heap_regs->AtomSigPending_
  Atom AtomSigPipe_;
#define AtomSigPipe Yap_heap_regs->AtomSigPipe_
  Atom AtomSigStackDump_;
#define AtomSigStackDump Yap_heap_regs->AtomSigStackDump_
  Atom AtomSigStatistics_;
#define AtomSigStatistics Yap_heap_regs->AtomSigStatistics_
  Atom AtomSigTrace_;
#define AtomSigTrace Yap_heap_regs->AtomSigTrace_
  Atom AtomSigUsr1_;
#define AtomSigUsr1 Yap_heap_regs->AtomSigUsr1_
  Atom AtomSigUsr2_;
#define AtomSigUsr2 Yap_heap_regs->AtomSigUsr2_
  Atom AtomSigVTAlarm_;
#define AtomSigVTAlarm Yap_heap_regs->AtomSigVTAlarm_
  Atom AtomSigWakeUp_;
#define AtomSigWakeUp Yap_heap_regs->AtomSigWakeUp_
  Atom AtomSlash_;
#define AtomSlash Yap_heap_regs->AtomSlash_
  Atom AtomSocket_;
#define AtomSocket Yap_heap_regs->AtomSocket_
  Atom AtomSourceSink_;
#define AtomSourceSink Yap_heap_regs->AtomSourceSink_
  Atom AtomSpy_;
#define AtomSpy Yap_heap_regs->AtomSpy_
  Atom AtomStack_;
#define AtomStack Yap_heap_regs->AtomStack_
  Atom AtomStackFree_;
#define AtomStackFree Yap_heap_regs->AtomStackFree_
  Atom AtomStartupSavedState_;
#define AtomStartupSavedState Yap_heap_regs->AtomStartupSavedState_
  Atom AtomStaticClause_;
#define AtomStaticClause Yap_heap_regs->AtomStaticClause_
  Atom AtomStaticProcedure_;
#define AtomStaticProcedure Yap_heap_regs->AtomStaticProcedure_
  Atom AtomStream_;
#define AtomStream Yap_heap_regs->AtomStream_
  Atom AtomVStream_;
#define AtomVStream Yap_heap_regs->AtomVStream_
  Atom AtomStreams_;
#define AtomStreams Yap_heap_regs->AtomStreams_
  Atom AtomStreamOrAlias_;
#define AtomStreamOrAlias Yap_heap_regs->AtomStreamOrAlias_
  Atom AtomStreamPos_;
#define AtomStreamPos Yap_heap_regs->AtomStreamPos_
  Atom AtomStreamPosition_;
#define AtomStreamPosition Yap_heap_regs->AtomStreamPosition_
  Atom AtomString_;
#define AtomString Yap_heap_regs->AtomString_
  Atom AtomSwi_;
#define AtomSwi Yap_heap_regs->AtomSwi_
  Atom AtomSyntaxError_;
#define AtomSyntaxError Yap_heap_regs->AtomSyntaxError_
  Atom AtomSyntaxErrorHandler_;
#define AtomSyntaxErrorHandler Yap_heap_regs->AtomSyntaxErrorHandler_
  Atom AtomSystem_;
#define AtomSystem Yap_heap_regs->AtomSystem_
  Atom AtomSystemError_;
#define AtomSystemError Yap_heap_regs->AtomSystemError_
  Atom AtomSystemLibraryDir_;
#define AtomSystemLibraryDir Yap_heap_regs->AtomSystemLibraryDir_
  Atom AtomTerm_;
#define AtomTerm Yap_heap_regs->AtomTerm_
  Atom AtomTerms_;
#define AtomTerms Yap_heap_regs->AtomTerms_
  Atom AtomTextStream_;
#define AtomTextStream Yap_heap_regs->AtomTextStream_
  Atom AtomThreads_;
#define AtomThreads Yap_heap_regs->AtomThreads_
  Atom AtomThrow_;
#define AtomThrow Yap_heap_regs->AtomThrow_
  Atom AtomTimeOutSpec_;
#define AtomTimeOutSpec Yap_heap_regs->AtomTimeOutSpec_
  Atom AtomTimeoutError_;
#define AtomTimeoutError Yap_heap_regs->AtomTimeoutError_
  Atom AtomTopLevelGoal_;
#define AtomTopLevelGoal Yap_heap_regs->AtomTopLevelGoal_
  Atom AtomTopThreadGoal_;
#define AtomTopThreadGoal Yap_heap_regs->AtomTopThreadGoal_
  Atom AtomTrail_;
#define AtomTrail Yap_heap_regs->AtomTrail_
  Atom AtomTrue_;
#define AtomTrue Yap_heap_regs->AtomTrue_
  Atom AtomTty_;
#define AtomTty Yap_heap_regs->AtomTty_
  Atom AtomTtys_;
#define AtomTtys Yap_heap_regs->AtomTtys_
  Atom AtomTypeError_;
#define AtomTypeError Yap_heap_regs->AtomTypeError_
  Atom AtomUndefined_;
#define AtomUndefined Yap_heap_regs->AtomUndefined_
  Atom AtomUndefp_;
#define AtomUndefp Yap_heap_regs->AtomUndefp_
  Atom AtomUnderflow_;
#define AtomUnderflow Yap_heap_regs->AtomUnderflow_
  Atom AtomUnificationStack_;
#define AtomUnificationStack Yap_heap_regs->AtomUnificationStack_
  Atom AtomUnsignedByte_;
#define AtomUnsignedByte Yap_heap_regs->AtomUnsignedByte_
  Atom AtomUnsignedChar_;
#define AtomUnsignedChar Yap_heap_regs->AtomUnsignedChar_
  Atom AtomUser_;
#define AtomUser Yap_heap_regs->AtomUser_
  Atom AtomUserErr_;
#define AtomUserErr Yap_heap_regs->AtomUserErr_
  Atom AtomUserIn_;
#define AtomUserIn Yap_heap_regs->AtomUserIn_
  Atom AtomUserOut_;
#define AtomUserOut Yap_heap_regs->AtomUserOut_
  Atom AtomVBar_;
#define AtomVBar Yap_heap_regs->AtomVBar_
  Atom AtomVar_;
#define AtomVar Yap_heap_regs->AtomVar_
  Atom AtomVariable_;
#define AtomVariable Yap_heap_regs->AtomVariable_
  Atom AtomVersionNumber_;
#define AtomVersionNumber Yap_heap_regs->AtomVersionNumber_
  Atom AtomWakeUpGoal_;
#define AtomWakeUpGoal Yap_heap_regs->AtomWakeUpGoal_
  Atom AtomWhen_;
#define AtomWhen Yap_heap_regs->AtomWhen_
  Atom AtomWrite_;
#define AtomWrite Yap_heap_regs->AtomWrite_
  Atom AtomYapHacks_;
#define AtomYapHacks Yap_heap_regs->AtomYapHacks_
  Atom AtomZeroDivisor_;
#define AtomZeroDivisor Yap_heap_regs->AtomZeroDivisor_
  Functor FunctorAfInet_;
#define FunctorAfInet Yap_heap_regs->FunctorAfInet_
  Functor FunctorAfLocal_;
#define FunctorAfLocal Yap_heap_regs->FunctorAfLocal_
  Functor FunctorAfUnix_;
#define FunctorAfUnix Yap_heap_regs->FunctorAfUnix_
  Functor FunctorAltNot_;
#define FunctorAltNot Yap_heap_regs->FunctorAltNot_
  Functor FunctorArg_;
#define FunctorArg Yap_heap_regs->FunctorArg_
  Functor FunctorArrayEntry_;
#define FunctorArrayEntry Yap_heap_regs->FunctorArrayEntry_
  Functor FunctorArrow_;
#define FunctorArrow Yap_heap_regs->FunctorArrow_
  Functor FunctorAssert_;
#define FunctorAssert Yap_heap_regs->FunctorAssert_
  Functor FunctorAtFoundOne_;
#define FunctorAtFoundOne Yap_heap_regs->FunctorAtFoundOne_
  Functor FunctorAtom_;
#define FunctorAtom Yap_heap_regs->FunctorAtom_
  Functor FunctorAtt1_;
#define FunctorAtt1 Yap_heap_regs->FunctorAtt1_
  Functor FunctorAttGoal_;
#define FunctorAttGoal Yap_heap_regs->FunctorAttGoal_
  Functor FunctorBraces_;
#define FunctorBraces Yap_heap_regs->FunctorBraces_
  Functor FunctorCall_;
#define FunctorCall Yap_heap_regs->FunctorCall_
  Functor FunctorCatch_;
#define FunctorCatch Yap_heap_regs->FunctorCatch_
  Functor FunctorChangeModule_;
#define FunctorChangeModule Yap_heap_regs->FunctorChangeModule_
  Functor FunctorCleanCall_;
#define FunctorCleanCall Yap_heap_regs->FunctorCleanCall_
  Functor FunctorClist_;
#define FunctorClist Yap_heap_regs->FunctorClist_
  Functor FunctorCodes_;
#define FunctorCodes Yap_heap_regs->FunctorCodes_
  Functor FunctorComma_;
#define FunctorComma Yap_heap_regs->FunctorComma_
  Functor FunctorContext2_;
#define FunctorContext2 Yap_heap_regs->FunctorContext2_
  Functor FunctorConsistencyError_;
#define FunctorConsistencyError Yap_heap_regs->FunctorConsistencyError_
  Functor FunctorCreep_;
#define FunctorCreep Yap_heap_regs->FunctorCreep_
  Functor FunctorCsult_;
#define FunctorCsult Yap_heap_regs->FunctorCsult_
  Functor FunctorCurrentModule_;
#define FunctorCurrentModule Yap_heap_regs->FunctorCurrentModule_
  Functor FunctorCutBy_;
#define FunctorCutBy Yap_heap_regs->FunctorCutBy_
  Functor FunctorDiff_;
#define FunctorDiff Yap_heap_regs->FunctorDiff_
  Functor FunctorDoLogUpdClause_;
#define FunctorDoLogUpdClause Yap_heap_regs->FunctorDoLogUpdClause_
  Functor FunctorDoLogUpdClause0_;
#define FunctorDoLogUpdClause0 Yap_heap_regs->FunctorDoLogUpdClause0_
  Functor FunctorDoLogUpdClauseErase_;
#define FunctorDoLogUpdClauseErase Yap_heap_regs->FunctorDoLogUpdClauseErase_
  Functor FunctorDoStaticClause_;
#define FunctorDoStaticClause Yap_heap_regs->FunctorDoStaticClause_
  Functor FunctorDomainError_;
#define FunctorDomainError Yap_heap_regs->FunctorDomainError_
  Functor FunctorDot_;
#define FunctorDot Yap_heap_regs->FunctorDot_
  Functor FunctorDot10_;
#define FunctorDot10 Yap_heap_regs->FunctorDot10_
  Functor FunctorDot11_;
#define FunctorDot11 Yap_heap_regs->FunctorDot11_
  Functor FunctorDot12_;
#define FunctorDot12 Yap_heap_regs->FunctorDot12_
  Functor FunctorDot2_;
#define FunctorDot2 Yap_heap_regs->FunctorDot2_
  Functor FunctorDot3_;
#define FunctorDot3 Yap_heap_regs->FunctorDot3_
  Functor FunctorDot4_;
#define FunctorDot4 Yap_heap_regs->FunctorDot4_
  Functor FunctorDot5_;
#define FunctorDot5 Yap_heap_regs->FunctorDot5_
  Functor FunctorDot6_;
#define FunctorDot6 Yap_heap_regs->FunctorDot6_
  Functor FunctorDot7_;
#define FunctorDot7 Yap_heap_regs->FunctorDot7_
  Functor FunctorDot8_;
#define FunctorDot8 Yap_heap_regs->FunctorDot8_
  Functor FunctorDot9_;
#define FunctorDot9 Yap_heap_regs->FunctorDot9_
  Functor FunctorEq_;
#define FunctorEq Yap_heap_regs->FunctorEq_
  Functor FunctorError_;
#define FunctorError Yap_heap_regs->FunctorError_
  Functor FunctorEvaluationError_;
#define FunctorEvaluationError Yap_heap_regs->FunctorEvaluationError_
  Functor FunctorExecute2InMod_;
#define FunctorExecute2InMod Yap_heap_regs->FunctorExecute2InMod_
  Functor FunctorExecuteInMod_;
#define FunctorExecuteInMod Yap_heap_regs->FunctorExecuteInMod_
  Functor FunctorExecuteWithin_;
#define FunctorExecuteWithin Yap_heap_regs->FunctorExecuteWithin_
  Functor FunctorExistenceError_;
#define FunctorExistenceError Yap_heap_regs->FunctorExistenceError_
  Functor FunctorFunctor_;
#define FunctorFunctor Yap_heap_regs->FunctorFunctor_
  Functor FunctorGAtom_;
#define FunctorGAtom Yap_heap_regs->FunctorGAtom_
  Functor FunctorGAtomic_;
#define FunctorGAtomic Yap_heap_regs->FunctorGAtomic_
  Functor FunctorGCompound_;
#define FunctorGCompound Yap_heap_regs->FunctorGCompound_
  Functor FunctorGFloat_;
#define FunctorGFloat Yap_heap_regs->FunctorGFloat_
  Functor FunctorGFormatAt_;
#define FunctorGFormatAt Yap_heap_regs->FunctorGFormatAt_
  Functor FunctorGInteger_;
#define FunctorGInteger Yap_heap_regs->FunctorGInteger_
  Functor FunctorGNumber_;
#define FunctorGNumber Yap_heap_regs->FunctorGNumber_
  Functor FunctorGPrimitive_;
#define FunctorGPrimitive Yap_heap_regs->FunctorGPrimitive_
  Functor FunctorGVar_;
#define FunctorGVar Yap_heap_regs->FunctorGVar_
  Functor FunctorGeneratePredInfo_;
#define FunctorGeneratePredInfo Yap_heap_regs->FunctorGeneratePredInfo_
  Functor FunctorGoalExpansion_;
#define FunctorGoalExpansion Yap_heap_regs->FunctorGoalExpansion_
  Functor FunctorHandleThrow_;
#define FunctorHandleThrow Yap_heap_regs->FunctorHandleThrow_
  Functor FunctorId_;
#define FunctorId Yap_heap_regs->FunctorId_
  Functor FunctorIs_;
#define FunctorIs Yap_heap_regs->FunctorIs_
  Functor FunctorLastExecuteWithin_;
#define FunctorLastExecuteWithin Yap_heap_regs->FunctorLastExecuteWithin_
  Functor FunctorList_;
#define FunctorList Yap_heap_regs->FunctorList_
  Functor FunctorMegaClause_;
#define FunctorMegaClause Yap_heap_regs->FunctorMegaClause_
  Functor FunctorMetaCall_;
#define FunctorMetaCall Yap_heap_regs->FunctorMetaCall_
  Functor FunctorMinus_;
#define FunctorMinus Yap_heap_regs->FunctorMinus_
  Functor FunctorModule_;
#define FunctorModule Yap_heap_regs->FunctorModule_
  Functor FunctorMultiFileClause_;
#define FunctorMultiFileClause Yap_heap_regs->FunctorMultiFileClause_
  Functor FunctorMutable_;
#define FunctorMutable Yap_heap_regs->FunctorMutable_
  Functor FunctorNotImplemented_;
#define FunctorNotImplemented Yap_heap_regs->FunctorNotImplemented_
  Functor FunctorNBQueue_;
#define FunctorNBQueue Yap_heap_regs->FunctorNBQueue_
  Functor FunctorNot_;
#define FunctorNot Yap_heap_regs->FunctorNot_
  Functor FunctorOr_;
#define FunctorOr Yap_heap_regs->FunctorOr_
  Functor FunctorPermissionError_;
#define FunctorPermissionError Yap_heap_regs->FunctorPermissionError_
  Functor FunctorPlus_;
#define FunctorPlus Yap_heap_regs->FunctorPlus_
  Functor FunctorPortray_;
#define FunctorPortray Yap_heap_regs->FunctorPortray_
  Functor FunctorPrologConstraint_;
#define FunctorPrologConstraint Yap_heap_regs->FunctorPrologConstraint_
  Functor FunctorQuery_;
#define FunctorQuery Yap_heap_regs->FunctorQuery_
  Functor FunctorRecordedWithKey_;
#define FunctorRecordedWithKey Yap_heap_regs->FunctorRecordedWithKey_
  Functor FunctorRDiv_;
#define FunctorRDiv Yap_heap_regs->FunctorRDiv_
  Functor FunctorRedoFreeze_;
#define FunctorRedoFreeze Yap_heap_regs->FunctorRedoFreeze_
  Functor FunctorRepresentationError_;
#define FunctorRepresentationError Yap_heap_regs->FunctorRepresentationError_
  Functor FunctorResourceError_;
#define FunctorResourceError Yap_heap_regs->FunctorResourceError_
  Functor FunctorRestoreRegs_;
#define FunctorRestoreRegs Yap_heap_regs->FunctorRestoreRegs_
  Functor FunctorRestoreRegs1_;
#define FunctorRestoreRegs1 Yap_heap_regs->FunctorRestoreRegs1_
  Functor FunctorSafe_;
#define FunctorSafe Yap_heap_regs->FunctorSafe_
  Functor FunctorSafeCallCleanup_;
#define FunctorSafeCallCleanup Yap_heap_regs->FunctorSafeCallCleanup_
  Functor FunctorSame_;
#define FunctorSame Yap_heap_regs->FunctorSame_
  Functor FunctorSlash_;
#define FunctorSlash Yap_heap_regs->FunctorSlash_
  Functor FunctorStaticClause_;
#define FunctorStaticClause Yap_heap_regs->FunctorStaticClause_
  Functor FunctorStream_;
#define FunctorStream Yap_heap_regs->FunctorStream_
  Functor FunctorStreamEOS_;
#define FunctorStreamEOS Yap_heap_regs->FunctorStreamEOS_
  Functor FunctorStreamPos_;
#define FunctorStreamPos Yap_heap_regs->FunctorStreamPos_
  Functor FunctorSyntaxError_;
#define FunctorSyntaxError Yap_heap_regs->FunctorSyntaxError_
  Functor FunctorShortSyntaxError_;
#define FunctorShortSyntaxError Yap_heap_regs->FunctorShortSyntaxError_
  Functor FunctorThreadRun_;
#define FunctorThreadRun Yap_heap_regs->FunctorThreadRun_
  Functor FunctorThrow_;
#define FunctorThrow Yap_heap_regs->FunctorThrow_
  Functor FunctorTimeoutError_;
#define FunctorTimeoutError Yap_heap_regs->FunctorTimeoutError_
  Functor FunctorTypeError_;
#define FunctorTypeError Yap_heap_regs->FunctorTypeError_
  Functor FunctorUMinus_;
#define FunctorUMinus Yap_heap_regs->FunctorUMinus_
  Functor FunctorUPlus_;
#define FunctorUPlus Yap_heap_regs->FunctorUPlus_
  Functor FunctorVBar_;
#define FunctorVBar Yap_heap_regs->FunctorVBar_
  Functor FunctorVar_;
#define FunctorVar Yap_heap_regs->FunctorVar_
