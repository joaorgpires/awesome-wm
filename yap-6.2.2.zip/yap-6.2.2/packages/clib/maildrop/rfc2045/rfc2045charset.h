/*
** Copyright 1998 - 1999 Double Precision, Inc.  See COPYING for
** distribution information.
*/

/* $Id$ */

#define	RFC2045CHARSET	"us-ascii"

#define	RFC2045MIMEMSG	"This is a MIME-formatted message.  If you see this text it means that your\nE-mail software does not support MIME-formatted messages.\n"
