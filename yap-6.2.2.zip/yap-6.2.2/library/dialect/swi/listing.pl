
% SWI compatibility only

:- module(listing, []).

